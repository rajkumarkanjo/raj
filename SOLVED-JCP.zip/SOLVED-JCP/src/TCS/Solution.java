package TCS;

import java.util.Scanner;

public class Solution {


    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);

        int N = sc.nextInt(); // first input

        int C = sc.nextInt(); // second input

        int [] value = new int[N];
        int [] capacity = new int[N];

        for (int i = 0 ; i <value.length ; i++ ){     //third input

            value[i] = sc.nextInt();

        }
        for (int i = 0 ; i <capacity.length ; i++ ){   // //fourth input

            value[i] = sc.nextInt();

        }
            int res = 0, index = 0;

            for (int i = value.length - 1; i >= index; i--)
            {
                res += value[i];

                index += C;
            }

        System.out.println(res);

    }

}
