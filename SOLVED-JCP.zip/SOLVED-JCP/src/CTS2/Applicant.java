package CTS2;

public class Applicant {

    private String panNumber;
    private String applicantName;
    private String companyBranch;
    private int  yearsOfExperience;
    private String applicantDesignation;

    public Applicant(String panNumber, String applicantName, String companyBranch, int yearsOfExperience, String applicantDesignation) {
        this.panNumber = panNumber;
        this.applicantName = applicantName;
        this.companyBranch = companyBranch;
        this.yearsOfExperience = yearsOfExperience;
        this.applicantDesignation = applicantDesignation;
    }

    public String getPanNumber() {
        return panNumber;
    }

    public void setPanNumber(String panNumber) {
        this.panNumber = panNumber;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getCompanyBranch() {
        return companyBranch;
    }

    public void setCompanyBranch(String companyBranch) {
        this.companyBranch = companyBranch;
    }

    public int getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(int yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }

    public String getApplicantDesignation() {
        return applicantDesignation;
    }

    public void setApplicantDesignation(String applicantDesignation) {
        this.applicantDesignation = applicantDesignation;
    }
}
