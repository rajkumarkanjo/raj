package CTS2;

import CTS.Customer;
import CTS.CustomerUtility;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ApplicantUtility {

    private Applicant[] applicantArray;

    public Applicant[] getApplicantArray() {
        return applicantArray;
    }

    public void setApplicantArray(Applicant[] applicantArray) {
        this.applicantArray = applicantArray;
    }

    public String[] findLoanAmount(){

        Applicant applicant;
        Applicant[] applicantsInputValidArray = getApplicantArray();
        String[]  finalBillAmount = new String[applicantsInputValidArray.length];

        for (int i = 0 ; i < applicantsInputValidArray.length ; i++ ){

            applicant = applicantsInputValidArray[i];

            double loanAmount=0.0;

            String panNumber = applicant.getPanNumber();
            String applicantName = applicant.getApplicantName();
            String companyBranch = applicant.getCompanyBranch();
            int yearsOfExperience = applicant.getYearsOfExperience();
            String applicantDesignation = applicant.getApplicantDesignation();

            if (applicantDesignation.equalsIgnoreCase("Manager") && yearsOfExperience >= 5){
                loanAmount = 400000;
            }else if (applicantDesignation.equalsIgnoreCase("Manager") && yearsOfExperience < 5){
                loanAmount = 200000;
            }else if (applicantDesignation.equalsIgnoreCase("ExecutiveOfficer") && yearsOfExperience >= 5){
                loanAmount = 200000;
            }else if (applicantDesignation.equalsIgnoreCase("ExecutiveOfficer") && yearsOfExperience < 5){
                loanAmount = 100000;
            }else if (applicantDesignation.equalsIgnoreCase("Associate") && yearsOfExperience >= 5){
                loanAmount = 400000;
            }else {
                loanAmount = 0.0;
            }
            String loan =  panNumber+":"+applicantName+":"+companyBranch+":"+yearsOfExperience+":"+applicantDesignation+":"+loanAmount;
            finalBillAmount[i] = loan;
        }
        return finalBillAmount;
    }
    public void addValidApplicant(String[] records){

        int arrSize = records.length;
        Applicant[] applicants = new Applicant[arrSize];

        for (int i = 0 ; i< records.length; i ++){

            String inputData = records[i];

            String [] splitData = inputData.split(":");
            String panNumber = splitData[0];
            String applicantName = splitData[1];
            String companyBranch = splitData[2];
            String yearsOfExperience = splitData[3];
            String applicantDesignation = splitData[4];

            if (ApplicantUtility.isValidPanCard(panNumber) == true){

                Applicant applicant = new Applicant(panNumber ,applicantName ,companyBranch,Integer.parseInt(yearsOfExperience),applicantDesignation );
                applicants[i] = applicant;
            }else{
                System.out.println("No Valid Applicant Found");
            }
        }
        setApplicantArray(applicants);
    }
    public static boolean isValidPanCard(String panNumber)
    {
        String regex = "^[A-Z]{5}(\\d){4}[A-Z]$";

        Pattern p = Pattern.compile(regex);

        if (panNumber == null) {
            return false;
        }
        Matcher m = p.matcher(panNumber);
        return m.matches();
    }
}
