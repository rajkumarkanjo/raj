package CTS2;


public class Main {

    public static void main(String[] args) {

        char[] crr ={97,98,99,100,101,102};
        byte[] brr ={97,98,99,100,101,102};

        String str1 = new String(crr);

        String str2 = new String(brr);

        System.out.println(str1+""+str2);


        Boolean b = new Boolean(false);
        System.out.println(b);

    }


}
