package CTS2;

import java.util.Scanner;

//sample input : "DTlPK5678K:raj:bangalore:5:manager";

public class Solution {

    public static void main(String[] args) {

       Scanner sc = new Scanner(System.in);

        System.out.println("Enter the Number of Applicant");
        int n = sc.nextInt();
        System.out.println("Enter the Applicants Details");

        int arrSize = n ;
        String[] inputArray = new String[arrSize];

            for (int i = 0 ; i < inputArray.length ;i++) {
                String str = sc.nextLine();
                inputArray[i] = str;
            }
        ApplicantUtility applicantUtility = new ApplicantUtility();
        applicantUtility.addValidApplicant(inputArray);
        String[] loanAmount = applicantUtility.findLoanAmount();
        for (String s : loanAmount) {
            System.out.println(s);
        }
    }
}