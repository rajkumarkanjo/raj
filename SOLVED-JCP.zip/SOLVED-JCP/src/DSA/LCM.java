/*
package DSA;

*/
/*

LCM of first N natural number
ex: if n = 3 then 1,2,3 LCM = 6
ref : https://www.geeksforgeeks.org/finding-lcm-two-array-numbers-without-using-gcd/
 *//*


public class LCM {

    public static void main(String[] args) {

        int arr[] = {1, 2, 3, 4, 5, 10, 20, 35};
        int n = arr.length;
       // int n = 8 ;
        long lcmofNnumbers = lcm(n , arr);
        System.out.println("lcmofNnumbers =  "+lcmofNnumbers);

    }

     public long static lcm(int n , int arr[]){


        return  0 ;
     }


}
*/
