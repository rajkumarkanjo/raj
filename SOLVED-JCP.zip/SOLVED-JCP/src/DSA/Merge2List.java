package DSA;

public class Merge2List {

    public static void main(String[] args) {

    }

}
class LinkedList
{
    //Function to merge two sorted linked list.
    void sortedMerge(LNode head1, LNode head2) {
        // This is a "method-only" submission.
        // You only need to complete this method



    }
}