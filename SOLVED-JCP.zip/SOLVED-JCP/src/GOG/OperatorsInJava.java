package GOG;

public class OperatorsInJava {
    public static void main(String[] args) {


    }

}
