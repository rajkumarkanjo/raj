package GOG;
/*
 Chocolate Distribution Problem
 */

public class CDP {

    public static void main(String[] args) {



    }

}

/*
Given an integral number N. The task is to find the count of digits present in this number.
EX:-
N = 1567
Number of digits = 4
 */


