import java.util.Arrays;
import java.util.PriorityQueue;

public class PQ {
    public static void main(String[] args) throws InterruptedException {
        /*PriorityQueue<String> pq = new PriorityQueue<>();
        pq.add("carrot");
        pq.add("apple");
        pq.add("banana");
        System.out.println(pq.poll()+ ":" + pq.peek());*/


        try {
            String d = "s";
        } catch (Exception ex) {
            throw new InterruptedException();
        } finally {
            Object d = "X";
        }

    /*    Object [] myObjects = {
          new Integer(12),
          new String("foo"),
          new Integer(5),
          new Boolean(true),
        };

        Arrays.sort(myObjects);

        for (int i = 0 ; i < myObjects.length ; i++){
            System.out.println(myObjects[i].toString());
            System.out.println(" ");
        }
    }*/
    }
}
