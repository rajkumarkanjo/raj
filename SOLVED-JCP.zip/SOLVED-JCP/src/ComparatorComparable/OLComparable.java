package ComparatorComparable;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class OLComparable {


    public static void main(String[] args) {


        List<OrderLine> orderLine = Arrays.asList(new OrderLine("1" , 2 , ""),
                new OrderLine("2" , 4 , ""),
                new OrderLine("1" , 5 , ""),
                new OrderLine("3" , 2 , ""));


        List<OrderLine> x = orderLine.stream().filter(c -> c.getQty() > 2).collect(Collectors.toList());

        System.out.println(x);

        Collections.sort(orderLine);

        System.out.println(orderLine.toString());

    }


}
