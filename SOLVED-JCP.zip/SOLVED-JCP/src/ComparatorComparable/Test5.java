package ComparatorComparable;

import java.util.Arrays;

public class Test5 {

    public static void main(String[] args) {

            int arr[] = { 0, 8, 3, 2, 7, 0, 6, 0, 0};
            int len = arr.length;
            Test5.test(arr, len);
            for (int i=0; i<len; i++)
                System.out.print(arr[i]+" ");
        }

        static void test(int arr[], int len)
        {
            int count = 0;
            //int zeroCount=0;
            for (int i = 0; i < len; i++) {    // O(N)
                if (arr[i] != 0){
                    arr[count] = arr[i];
                    count++;
                }
         /*else{
            zeroCount++;
         }*/
            }                              // 0(N) + O(N) = O(N)
            while (count < len)
                arr[count++] = 0;

        }
    }
       /* int[] arr = {0,1,4,5,8,0,6,0};  // 0(n)
        int tempIndex =-1;
        for(int i=0; i<arr.length; i++){

            if(tempIndex ==-1 && arr[i] == 0){
                tempIndex = i; //1
            }
           // System.out.println(arr[i]);
            if(tempIndex>-1 && arr[tempIndex] ==0 && arr[i]>0 ){
                arr[tempIndex] = arr[i];
                arr[i] = 0;
                --i;
                tempIndex = -1;
            }
        }

        System.out.println(Arrays.toString(arr));
    }*/


        /*String input = "457080200";
        char [] chars = input.toCharArray();
        char temp ;
        for ( int i =0 ; i < chars.length ; i++){

            if (chars[i] == '0'){

                temp = chars[i];

                for (int j = i ; j < chars.length-1 ; j++ ){

                    chars[j] = chars[j+1];
                }

                chars[chars.length-1] = temp;
            }
        }
        System.out.println(Arrays.toString(chars));
    }*/


