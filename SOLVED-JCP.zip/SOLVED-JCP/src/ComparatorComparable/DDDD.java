package ComparatorComparable;

import java.util.HashMap;
import java.util.Map;

// public
//prorected
//default
// private

class A {

    void show() {
        System.out.println("1");
    }
}

class B extends  A{

    void show() {

        System.out.println("3");
    }
    void demo() {

        System.out.println("4");
    }
}

public class DDDD {


    public static void main(String[] args) {

          A a = new B();

        //  ((B) a ).demo();

        if (a instanceof B){
        //    System.out.println(); ((B) a ).demo();
        }

/*
        Map<String,Integer>  map = new HashMap<>();

        map.put("Anubhab",1);
        map.get(new String("Anubhab")); //*/

        //  String s3 = s2;
        //   System.out.println(s3.hashCode());

        //     s2 = s2+s1;

        String s1 = "ABC";   // pool
        String s2 = new String("ABC"); // heap

          s2 = "ABC";

             System.out.println(s1==s2); // false
    }

}

