

public class InfyTQ_2 {




    public static void main(String[] args) {





    }



}
